<?php


namespace Support;

/**
 * @mixin \Eloquent
 */
class Model extends \Illuminate\Database\Eloquent\Model
{

}
