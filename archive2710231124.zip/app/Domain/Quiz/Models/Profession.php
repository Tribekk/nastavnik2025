<?php

namespace Domain\Quiz\Models;

use Illuminate\Database\Eloquent\Model;

class Profession extends Model
{
    //
}
