<?php

namespace Domain\Quiz\Models;

use Illuminate\Database\Eloquent\Model;

class TypeTraitValue extends Model
{
    //
}
