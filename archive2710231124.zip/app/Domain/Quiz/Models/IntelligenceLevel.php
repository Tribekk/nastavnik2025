<?php

namespace Domain\Quiz\Models;

use Support\Model;

class IntelligenceLevel extends Model
{
    protected $guarded = [];
}
