<?php

namespace App\Http\Controllers\admin\projects;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class projects extends Controller
{
    //
}
