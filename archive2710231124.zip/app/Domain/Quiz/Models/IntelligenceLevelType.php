<?php

namespace Domain\Quiz\Models;

use Support\Model;

class IntelligenceLevelType extends Model
{
    protected $guarded = [];
}
