<?php

namespace Domain\Consultation\Models;

use Illuminate\Database\Eloquent\Model;

class ConsultationResultType extends Model
{
    protected $guarded = ['id'];
}

