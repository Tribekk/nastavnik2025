<?php

namespace Domain\Admin\Models;

use Illuminate\Database\Eloquent\Model;

class LoyaltyLevel extends Model
{
    protected $guarded = ['id'];
}
