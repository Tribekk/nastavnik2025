<?php

namespace Domain\Orgunit\Models;

use Illuminate\Database\Query\Builder;
use Support\Model;

class OrgunitNote extends Model
{
    protected $guarded = ['id'];

}
