<?php

namespace Domain\Admin\Models;

use Illuminate\Database\Eloquent\Model;

class TypeEducationalOrganization extends Model
{
    protected $table = "types_of_educational_organization";

    protected $guarded = ['id'];
}
